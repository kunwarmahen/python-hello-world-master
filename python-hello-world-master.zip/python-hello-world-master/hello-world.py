#--------------------------------------------------------------------------------------------
#  Copyright (c) Red Hat, Inc. All rights reserved.
#  Licensed under the MIT License. See LICENSE in the project root for license information.
#--------------------------------------------------------------------------------------------

# This program prints Hello, world!

str = 'world'
print('Hello, ' + str + '!')